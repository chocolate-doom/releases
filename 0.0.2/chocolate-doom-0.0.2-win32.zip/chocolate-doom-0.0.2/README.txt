
Chocolate Doom is a Doom source port which is designed to behave as closely
as possible to the original DOS Doom executables.

